package htw.webtech.todo.app.dto;

public class CreateFilmDto {
    private String title;
    private Integer minutes; // plural im DTO
    private String notes;

    public CreateFilmDto() { }

    public CreateFilmDto(String title, Integer minutes, String notes) {
        this.title = title;
        this.minutes = minutes;
        this.notes = notes;
    }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public Integer getMinutes() { return minutes; }
    public void setMinutes(Integer minutes) { this.minutes = minutes; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
