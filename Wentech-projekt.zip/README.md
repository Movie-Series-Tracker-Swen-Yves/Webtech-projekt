# Webtech-projekt README
# Swen Sucker und Leon

# Das Projekt speichert den Film und Serien Fortschritt. 
# Wenn man auf Details drückt, wird die Datenbank OMDB verbunden und generiert eine passende Beschreibung und Informationen.

# TO DO LIST (Eigene)

# Menü leiste  mit funktion serie/Film/ Bücher anzeigen
# Abgeschlossene Folge bei Minute angeben möglich bei Serie
# sprache bei englischer Beschreibung auf deutsch umstellen
# Einträge bearbeiten/ löschen Funktion
# Speichern der Website Einträge trotz code re-runns
# Design in JavaSkript/CSS anpassen


# Check List für Milestones

# Milestones (aktuell!)
# M1: Thema überlegt, Paar gefunden, GitHub-Repo erstellt, Entity-Klasse überlegt, Spring App mit GET-Route gepusht --> Deadline: 19. Oktober
# M2: Vue.js-App zu GitHub gepusht, mind. 1 eigene Unterkomponente, die etwas mit v-for rendert --> Deadline: 9. November
# M3: Frontend und Backend auf Render deployed, Frontend ruft GET-Route auf --> Deadline: 23. November
# M4: Backend hat REST-Schnittstelle und kann Daten in Datenbank speichern, Frontend ruft POST-Route auf --> Deadline: 14. Dezember
# Finale Projekt-Präsentation: 19. Januar bis 23. Januar --> Deadline: Sonntag, 18. Januar, 23:59 Uhr

